﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

//RA: 	0030482013021
namespace Aval_LP2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Resultado.Items.Clear();
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            double[,] meses = new double[1, 4];
            double mesTotal = 0;
            double total = 0;

            string semVal;

            int m = 0;

            if(m < 1)
            {

                for (int sem = 0; sem < 4; sem++)
                {
                    semVal = Interaction.InputBox("valor recebido na semana " + (sem + 1) + " do mes " + (m + 1), "Digite os valores", "0");
                    double val;

                    try
                    {
                        val = Double.Parse(semVal);
                        meses[m, sem] = val;
                        mesTotal += val;
                        total += val;
                    }
                    catch
                    {
                        val = 0;
                        DialogResult show = MessageBox.Show("Deseja cancelar?", "Cancelar", MessageBoxButtons.YesNo);

                        if (show == DialogResult.Yes)
                        {
                           return;
                        }
                    
                    }


                    Resultado.BeginUpdate();

                    Resultado.Items.Add("Total do mes: " + (m + 1) + " semana: " + (sem + 1) + " = " + String.Format("{0:C2}", val));

                    Resultado.EndUpdate();
                }

                Resultado.BeginUpdate();

                Resultado.Items.Add("--------------Total do mês: " + String.Format("{0:C2}---------------", mesTotal));

                Resultado.EndUpdate();

                mesTotal = 0;
            }
        }


    }
}
